# TokenScope - Token-Aware Directory Explorer for LLMs
#
# A Model Context Protocol (MCP) server for token-aware directory exploration and analysis.
